﻿$(document).ready(function () {
    $(".owl-carousel").owlCarousel({
        loop: true,
        items: 3,
        margin: 20,
        nav: true,
        navText: ["<i class='fa fa-chevron-left'></i>", "<i class='fa fa-chevron-right'></i>"],
    });
});